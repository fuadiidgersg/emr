"use client"

import { ActivityLog } from "@/components/admin/activity-log"

export default function AdminActivityLogsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Activity Logs</h1>
        <p className="text-muted-foreground mt-2">System audit trail and user activities</p>
      </div>
      <ActivityLog />
    </div>
  )
}
