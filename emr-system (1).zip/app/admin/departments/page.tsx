"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function AdminDepartmentsPage() {
  const departments = [
    { id: "1", name: "General Medicine", head: "Dr. Amina Hassan", staff: 12 },
    { id: "2", name: "Surgery", head: "Dr. Hassan Ali", staff: 8 },
    { id: "3", name: "Pediatrics", head: "Dr. Fatima Mohamed", staff: 6 },
    { id: "4", name: "Pharmacy", head: "Pharmacist Ali", staff: 5 },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Departments</h1>
        <p className="text-muted-foreground mt-2">Manage hospital departments</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {departments.map((dept) => (
          <Card key={dept.id}>
            <CardHeader>
              <CardTitle>{dept.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-sm text-muted-foreground">Department Head</p>
                <p className="font-medium">{dept.head}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Staff Members</p>
                <Badge className="bg-blue-100 text-blue-800">{dept.staff} staff</Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
