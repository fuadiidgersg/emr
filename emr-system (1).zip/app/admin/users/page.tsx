"use client"

import { UsersTable } from "@/components/admin/users-table"

export default function AdminUsersPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">System Users</h1>
        <p className="text-muted-foreground mt-2">Manage all system users and their roles</p>
      </div>
      <UsersTable />
    </div>
  )
}
