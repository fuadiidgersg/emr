"use client"

import { VitalsForm } from "@/components/nurse/vitals-form"
import { WardPatientsList } from "@/components/nurse/ward-patients-list"

export default function NurseDashboard() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <VitalsForm />
      </div>
      <div>
        <WardPatientsList />
      </div>
    </div>
  )
}
