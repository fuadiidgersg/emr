"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export default function NurseMedicationPage() {
  const medications = [
    {
      id: "1",
      patient: "Ahmed Hassan",
      medicine: "Paracetamol 500mg",
      dosage: "1 tablet",
      frequency: "3x daily",
      status: "pending",
    },
    {
      id: "2",
      patient: "Fatima Mohamed",
      medicine: "Amoxicillin 250mg",
      dosage: "1 capsule",
      frequency: "2x daily",
      status: "given",
    },
    {
      id: "3",
      patient: "Ali Ibrahim",
      medicine: "Ibuprofen 400mg",
      dosage: "1 tablet",
      frequency: "2x daily",
      status: "pending",
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Medication Administration</h1>
        <p className="text-muted-foreground mt-2">Track medication administration</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Pending Medications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {medications.map((med) => (
              <div key={med.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="flex-1">
                  <p className="font-medium">{med.patient}</p>
                  <p className="text-sm text-muted-foreground">{med.medicine}</p>
                  <p className="text-xs text-muted-foreground">
                    {med.dosage} - {med.frequency}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge
                    className={med.status === "given" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}
                  >
                    {med.status}
                  </Badge>
                  {med.status === "pending" && <Button size="sm">Mark Given</Button>}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
