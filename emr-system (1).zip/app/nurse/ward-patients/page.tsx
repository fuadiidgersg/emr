"use client"

import { WardPatientsList } from "@/components/nurse/ward-patients-list"

export default function NurseWardPatientsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Ward Patients</h1>
        <p className="text-muted-foreground mt-2">Monitor all patients in the ward</p>
      </div>
      <WardPatientsList />
    </div>
  )
}
