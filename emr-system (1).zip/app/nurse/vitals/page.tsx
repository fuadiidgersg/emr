"use client"

import { VitalsForm } from "@/components/nurse/vitals-form"

export default function NurseVitalsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Record Vitals</h1>
        <p className="text-muted-foreground mt-2">Record patient vital signs</p>
      </div>
      <VitalsForm />
    </div>
  )
}
