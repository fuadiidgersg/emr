"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { useRouter } from "next/navigation"
import { Icon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function LoginPage() {
  const { login, isLoading } = useAuth()
  const { language, setLanguage } = useLanguage()
  const router = useRouter()

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [role, setRole] = useState<"doctor" | "nurse" | "pharmacist" | "admin" | "patient">("doctor")
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!email || !password) {
      setError("Please fill in all fields")
      return
    }

    try {
      await login(email, password, role)
      router.push(`/${role}/dashboard`)
    } catch (err) {
      setError("Login failed. Please try again.")
    }
  }

  const demoAccounts = [
    { role: "doctor" as const, email: "doctor@hospital.com", password: "demo123" },
    { role: "nurse" as const, email: "nurse@hospital.com", password: "demo123" },
    { role: "pharmacist" as const, email: "pharmacist@hospital.com", password: "demo123" },
    { role: "admin" as const, email: "admin@hospital.com", password: "demo123" },
    { role: "patient" as const, email: "patient@hospital.com", password: "demo123" },
  ]

  const handleDemoLogin = async (demoRole: typeof role) => {
    const demo = demoAccounts.find((acc) => acc.role === demoRole)
    if (demo) {
      try {
        await login(demo.email, demo.password, demo.role)
        router.push(`/${demo.role}/dashboard`)
      } catch (err) {
        setError("Demo login failed")
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Language Toggle */}
        <div className="flex justify-end mb-4">
          <div className="flex items-center gap-2 bg-card rounded-lg p-2 border border-border">
            <Icon name="Globe" className="w-4 h-4" />
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as "en" | "so")}
              className="bg-transparent text-sm font-medium focus:outline-none"
            >
              <option value="en">English</option>
              <option value="so">Somali</option>
            </select>
          </div>
        </div>

        {/* Login Card */}
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <div className="text-4xl font-bold text-primary mb-2">EMR</div>
            <CardTitle>{t("login", language)}</CardTitle>
            <p className="text-sm text-muted-foreground mt-2">Hospital Management System</p>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-sm text-destructive">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium mb-2">{t("email", language)}</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="user@hospital.com"
                  className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">{t("password", language)}</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">{t("role", language)}</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as typeof role)}
                  className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="doctor">{t("doctor", language)}</option>
                  <option value="nurse">{t("nurse", language)}</option>
                  <option value="pharmacist">{t("pharmacist", language)}</option>
                  <option value="admin">{t("admin", language)}</option>
                  <option value="patient">{t("patient", language)}</option>
                </select>
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Loading..." : t("signIn", language)}
              </Button>
            </form>

            {/* Demo Accounts */}
            <div className="mt-6 pt-6 border-t border-border">
              <p className="text-sm font-medium text-center mb-3">Demo Accounts</p>
              <div className="grid grid-cols-2 gap-2">
                {demoAccounts.map((demo) => (
                  <button
                    key={demo.role}
                    type="button"
                    onClick={() => handleDemoLogin(demo.role)}
                    className="px-3 py-2 text-xs font-medium capitalize rounded-lg border border-border hover:bg-accent transition-colors"
                  >
                    {demo.role}
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground mt-4">
          Hospital EMR System - Multilingual Support (English & Somali)
        </p>
      </div>
    </div>
  )
}
