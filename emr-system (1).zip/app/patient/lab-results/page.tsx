"use client"

import { LabResultsCard } from "@/components/patient/lab-results-card"

export default function PatientLabResultsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Lab Results</h1>
        <p className="text-muted-foreground mt-2">View your laboratory test results</p>
      </div>
      <LabResultsCard />
    </div>
  )
}
