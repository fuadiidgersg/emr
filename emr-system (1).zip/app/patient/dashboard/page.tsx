"use client"

import { AppointmentsCard } from "@/components/patient/appointments-card"
import { PrescriptionsCard } from "@/components/patient/prescriptions-card"
import { LabResultsCard } from "@/components/patient/lab-results-card"
import { ProfileCard } from "@/components/patient/profile-card"

export default function PatientDashboard() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <AppointmentsCard />
        <PrescriptionsCard />
        <LabResultsCard />
      </div>
      <div>
        <ProfileCard />
      </div>
    </div>
  )
}
