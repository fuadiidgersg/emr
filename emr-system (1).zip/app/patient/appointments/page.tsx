"use client"

import { AppointmentsCard } from "@/components/patient/appointments-card"

export default function PatientAppointmentsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">My Appointments</h1>
        <p className="text-muted-foreground mt-2">View and manage your appointments</p>
      </div>
      <AppointmentsCard />
    </div>
  )
}
