"use client"

import type React from "react"
import { PatientSidebar } from "@/components/patient/sidebar"
import { PatientHeader } from "@/components/patient/patient-header"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { usePathname } from "next/navigation"

export default function PatientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { isAuthenticated, isLoading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  const getActivePage = () => {
    if (pathname.includes("/appointments")) return "appointments"
    if (pathname.includes("/prescriptions")) return "prescriptions"
    if (pathname.includes("/lab-results")) return "lab-results"
    if (pathname.includes("/profile")) return "profile"
    return "dashboard"
  }

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, isLoading, router])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="flex h-screen bg-background">
      <PatientSidebar active={getActivePage()} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <PatientHeader />
        <main className="flex-1 overflow-auto p-6">{children}</main>
      </div>
    </div>
  )
}
