"use client"

import { PrescriptionsCard } from "@/components/patient/prescriptions-card"

export default function PatientPrescriptionsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">My Prescriptions</h1>
        <p className="text-muted-foreground mt-2">View your active prescriptions</p>
      </div>
      <PrescriptionsCard />
    </div>
  )
}
