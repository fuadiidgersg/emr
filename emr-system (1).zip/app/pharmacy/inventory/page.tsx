"use client"

import { InventoryTable } from "@/components/pharmacy/inventory-table"

export default function PharmacyInventoryPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Medicine Inventory</h1>
        <p className="text-muted-foreground mt-2">Manage medicine stock and inventory</p>
      </div>
      <InventoryTable />
    </div>
  )
}
