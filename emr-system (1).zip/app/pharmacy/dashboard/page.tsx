"use client"

import { InventoryTable } from "@/components/pharmacy/inventory-table"
import { PrescriptionsList } from "@/components/pharmacy/prescriptions-list"

export default function PharmacyDashboard() {
  return (
    <div className="space-y-6">
      <InventoryTable />
      <PrescriptionsList />
    </div>
  )
}
