"use client"

import { DoctorSidebar } from "@/components/doctor/sidebar"
import { DoctorHeader } from "@/components/doctor/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { useState } from "react"

export default function PrescriptionsPage() {
  const { language } = useLanguage()
  const [prescriptions, setPrescriptions] = useState([
    {
      id: 1,
      patient: "Ahmed Hassan",
      medicine: "Amoxicillin",
      dosage: "500mg",
      frequency: "3x daily",
      duration: "7 days",
      date: "2025-10-15",
    },
    {
      id: 2,
      patient: "Fatima Mohamed",
      medicine: "Ibuprofen",
      dosage: "200mg",
      frequency: "2x daily",
      duration: "5 days",
      date: "2025-10-14",
    },
    {
      id: 3,
      patient: "Ali Ibrahim",
      medicine: "Metformin",
      dosage: "1000mg",
      frequency: "2x daily",
      duration: "30 days",
      date: "2025-10-10",
    },
    {
      id: 4,
      patient: "Zainab Ali",
      medicine: "Aspirin",
      dosage: "100mg",
      frequency: "1x daily",
      duration: "10 days",
      date: "2025-10-16",
    },
  ])
  const [selectedRx, setSelectedRx] = useState<(typeof prescriptions)[0] | null>(null)
  const [editForm, setEditForm] = useState<(typeof prescriptions)[0] | null>(null)

  const handleSaveEdit = () => {
    if (editForm) {
      setPrescriptions(prescriptions.map((rx) => (rx.id === editForm.id ? editForm : rx)))
      setEditForm(null)
      setSelectedRx(null)
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <DoctorSidebar active="prescriptions" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <DoctorHeader />
        <main className="flex-1 overflow-auto p-6">
          <div className="space-y-6">
            <h1 className="text-3xl font-bold">{t("prescriptions", language)}</h1>

            <Card>
              <CardHeader>
                <CardTitle>Prescriptions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-3 px-4 font-semibold">Patient</th>
                        <th className="text-left py-3 px-4 font-semibold">Medicine</th>
                        <th className="text-left py-3 px-4 font-semibold">Dosage</th>
                        <th className="text-left py-3 px-4 font-semibold">Frequency</th>
                        <th className="text-left py-3 px-4 font-semibold">Duration</th>
                        <th className="text-left py-3 px-4 font-semibold">Date</th>
                        <th className="text-left py-3 px-4 font-semibold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {prescriptions.map((rx) => (
                        <tr key={rx.id} className="border-b border-border hover:bg-accent/50">
                          <td className="py-3 px-4">{rx.patient}</td>
                          <td className="py-3 px-4">{rx.medicine}</td>
                          <td className="py-3 px-4">{rx.dosage}</td>
                          <td className="py-3 px-4">{rx.frequency}</td>
                          <td className="py-3 px-4">{rx.duration}</td>
                          <td className="py-3 px-4">{rx.date}</td>
                          <td className="py-3 px-4">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedRx(rx)
                                setEditForm(rx)
                              }}
                            >
                              Edit
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {editForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Edit Prescription</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Patient</label>
                <input
                  type="text"
                  value={editForm.patient}
                  onChange={(e) => setEditForm({ ...editForm, patient: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Medicine</label>
                <input
                  type="text"
                  value={editForm.medicine}
                  onChange={(e) => setEditForm({ ...editForm, medicine: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Dosage</label>
                  <input
                    type="text"
                    value={editForm.dosage}
                    onChange={(e) => setEditForm({ ...editForm, dosage: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Frequency</label>
                  <input
                    type="text"
                    value={editForm.frequency}
                    onChange={(e) => setEditForm({ ...editForm, frequency: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Duration</label>
                <input
                  type="text"
                  value={editForm.duration}
                  onChange={(e) => setEditForm({ ...editForm, duration: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={handleSaveEdit} className="flex-1">
                  Save Changes
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 bg-transparent"
                  onClick={() => {
                    setEditForm(null)
                    setSelectedRx(null)
                  }}
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
