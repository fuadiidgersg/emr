"use client"

import { OverviewCards } from "@/components/doctor/overview-cards"
import { AppointmentsTable } from "@/components/doctor/appointments-table"

export default function DoctorDashboard() {
  return (
    <div className="space-y-6">
      <OverviewCards />
      <AppointmentsTable />
    </div>
  )
}
