"use client"

import type React from "react"

import { DoctorSidebar } from "@/components/doctor/sidebar"
import { DoctorHeader } from "@/components/doctor/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Icon } from "@/components/icons"
import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { useState } from "react"

export default function AppointmentsPage() {
  const { language } = useLanguage()
  const [showAddForm, setShowAddForm] = useState(false)
  const [appointments, setAppointments] = useState([
    { id: 1, patient: "Ahmed Hassan", date: "2025-10-20", time: "09:00 AM", type: "Consultation", status: "Scheduled" },
    { id: 2, patient: "Fatima Mohamed", date: "2025-10-20", time: "10:30 AM", type: "Follow-up", status: "Scheduled" },
    { id: 3, patient: "Ali Ibrahim", date: "2025-10-21", time: "02:00 PM", type: "Checkup", status: "Scheduled" },
  ])
  const [formData, setFormData] = useState({ patient: "", date: "", time: "", type: "Consultation" })

  const handleAddAppointment = (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.patient && formData.date && formData.time) {
      setAppointments([
        ...appointments,
        {
          id: appointments.length + 1,
          patient: formData.patient,
          date: formData.date,
          time: formData.time,
          type: formData.type,
          status: "Scheduled",
        },
      ])
      setFormData({ patient: "", date: "", time: "", type: "Consultation" })
      setShowAddForm(false)
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <DoctorSidebar active="appointments" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <DoctorHeader />
        <main className="flex-1 overflow-auto p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold">{t("appointments", language)}</h1>
              <Button onClick={() => setShowAddForm(!showAddForm)} className="gap-2">
                <Icon name="Plus" className="w-4 h-4" />
                Add Appointment
              </Button>
            </div>

            {showAddForm && (
              <Card className="border-primary/50 bg-primary/5">
                <CardHeader>
                  <CardTitle>New Appointment</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddAppointment} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Patient Name</label>
                        <input
                          type="text"
                          value={formData.patient}
                          onChange={(e) => setFormData({ ...formData, patient: e.target.value })}
                          placeholder="Enter patient name"
                          className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Date</label>
                        <input
                          type="date"
                          value={formData.date}
                          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                          className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Time</label>
                        <input
                          type="time"
                          value={formData.time}
                          onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                          className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Type</label>
                        <select
                          value={formData.type}
                          onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                          className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        >
                          <option>Consultation</option>
                          <option>Follow-up</option>
                          <option>Checkup</option>
                          <option>Surgery</option>
                        </select>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button type="submit">Save Appointment</Button>
                      <Button type="button" variant="outline" onClick={() => setShowAddForm(false)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Upcoming Appointments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-3 px-4 font-semibold">Patient</th>
                        <th className="text-left py-3 px-4 font-semibold">Date</th>
                        <th className="text-left py-3 px-4 font-semibold">Time</th>
                        <th className="text-left py-3 px-4 font-semibold">Type</th>
                        <th className="text-left py-3 px-4 font-semibold">Status</th>
                        <th className="text-left py-3 px-4 font-semibold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {appointments.map((apt) => (
                        <tr key={apt.id} className="border-b border-border hover:bg-accent/50">
                          <td className="py-3 px-4">{apt.patient}</td>
                          <td className="py-3 px-4">{apt.date}</td>
                          <td className="py-3 px-4">{apt.time}</td>
                          <td className="py-3 px-4">{apt.type}</td>
                          <td className="py-3 px-4">
                            <span className="px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800">
                              {apt.status}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
