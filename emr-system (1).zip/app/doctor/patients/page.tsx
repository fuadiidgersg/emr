"use client"

import { DoctorSidebar } from "@/components/doctor/sidebar"
import { DoctorHeader } from "@/components/doctor/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Icon } from "@/components/icons"
import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { useState } from "react"

export default function PatientsPage() {
  const { language } = useLanguage()
  const [patients] = useState([
    {
      id: 1,
      name: "Ahmed Hassan",
      age: 45,
      gender: "Male",
      lastVisit: "2025-10-15",
      status: "Active",
      phone: "+252-61-123-4567",
      email: "ahmed@email.com",
    },
    {
      id: 2,
      name: "Fatima Mohamed",
      age: 32,
      gender: "Female",
      lastVisit: "2025-10-14",
      status: "Active",
      phone: "+252-61-234-5678",
      email: "fatima@email.com",
    },
    {
      id: 3,
      name: "Ali Ibrahim",
      age: 58,
      gender: "Male",
      lastVisit: "2025-10-10",
      status: "Inactive",
      phone: "+252-61-345-6789",
      email: "ali@email.com",
    },
    {
      id: 4,
      name: "Zainab Ali",
      age: 28,
      gender: "Female",
      lastVisit: "2025-10-16",
      status: "Active",
      phone: "+252-61-456-7890",
      email: "zainab@email.com",
    },
    {
      id: 5,
      name: "Hassan Abdi",
      age: 52,
      gender: "Male",
      lastVisit: "2025-10-12",
      status: "Active",
      phone: "+252-61-567-8901",
      email: "hassan@email.com",
    },
  ])
  const [selectedPatient, setSelectedPatient] = useState<(typeof patients)[0] | null>(null)

  return (
    <div className="flex h-screen bg-background">
      <DoctorSidebar active="patients" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <DoctorHeader />
        <main className="flex-1 overflow-auto p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold">{t("patients", language)}</h1>
              <Button className="gap-2">
                <Icon name="Plus" className="w-4 h-4" />
                Add Patient
              </Button>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Patient List</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-3 px-4 font-semibold">Name</th>
                        <th className="text-left py-3 px-4 font-semibold">Age</th>
                        <th className="text-left py-3 px-4 font-semibold">Gender</th>
                        <th className="text-left py-3 px-4 font-semibold">Last Visit</th>
                        <th className="text-left py-3 px-4 font-semibold">Status</th>
                        <th className="text-left py-3 px-4 font-semibold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {patients.map((patient) => (
                        <tr key={patient.id} className="border-b border-border hover:bg-accent/50">
                          <td className="py-3 px-4">{patient.name}</td>
                          <td className="py-3 px-4">{patient.age}</td>
                          <td className="py-3 px-4">{patient.gender}</td>
                          <td className="py-3 px-4">{patient.lastVisit}</td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-1 rounded text-xs font-medium ${
                                patient.status === "Active"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-gray-100 text-gray-800"
                              }`}
                            >
                              {patient.status}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <Button variant="outline" size="sm" onClick={() => setSelectedPatient(patient)}>
                              View
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {selectedPatient && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Patient Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Name</label>
                <p className="text-lg font-semibold">{selectedPatient.name}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Age</label>
                  <p className="text-lg font-semibold">{selectedPatient.age}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Gender</label>
                  <p className="text-lg font-semibold">{selectedPatient.gender}</p>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Phone</label>
                <p className="text-base">{selectedPatient.phone}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Email</label>
                <p className="text-base">{selectedPatient.email}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Last Visit</label>
                <p className="text-base">{selectedPatient.lastVisit}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Status</label>
                <p className="text-base font-semibold">{selectedPatient.status}</p>
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={() => setSelectedPatient(null)} className="flex-1">
                  Close
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  Edit Patient
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
