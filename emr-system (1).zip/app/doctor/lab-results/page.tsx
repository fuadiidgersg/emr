"use client"

import { DoctorSidebar } from "@/components/doctor/sidebar"
import { DoctorHeader } from "@/components/doctor/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { useState } from "react"

export default function LabResultsPage() {
  const { language } = useLanguage()
  const [results] = useState([
    {
      id: 1,
      patient: "Ahmed Hassan",
      test: "Blood Test",
      date: "2025-10-15",
      status: "Completed",
      result: "Normal",
      details: "All values within normal range",
    },
    {
      id: 2,
      patient: "Fatima Mohamed",
      test: "X-Ray",
      date: "2025-10-14",
      status: "Completed",
      result: "Normal",
      details: "No abnormalities detected",
    },
    {
      id: 3,
      patient: "Ali Ibrahim",
      test: "CT Scan",
      date: "2025-10-10",
      status: "Pending",
      result: "-",
      details: "Awaiting radiologist review",
    },
    {
      id: 4,
      patient: "Zainab Ali",
      test: "Ultrasound",
      date: "2025-10-16",
      status: "Completed",
      result: "Normal",
      details: "All organs appear normal",
    },
  ])
  const [selectedResult, setSelectedResult] = useState<(typeof results)[0] | null>(null)

  return (
    <div className="flex h-screen bg-background">
      <DoctorSidebar active="lab-results" />
      <div className="flex-1 flex flex-col overflow-hidden">
        <DoctorHeader />
        <main className="flex-1 overflow-auto p-6">
          <div className="space-y-6">
            <h1 className="text-3xl font-bold">{t("labResults", language)}</h1>

            <Card>
              <CardHeader>
                <CardTitle>Lab Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-3 px-4 font-semibold">Patient</th>
                        <th className="text-left py-3 px-4 font-semibold">Test</th>
                        <th className="text-left py-3 px-4 font-semibold">Date</th>
                        <th className="text-left py-3 px-4 font-semibold">Status</th>
                        <th className="text-left py-3 px-4 font-semibold">Result</th>
                        <th className="text-left py-3 px-4 font-semibold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.map((result) => (
                        <tr key={result.id} className="border-b border-border hover:bg-accent/50">
                          <td className="py-3 px-4">{result.patient}</td>
                          <td className="py-3 px-4">{result.test}</td>
                          <td className="py-3 px-4">{result.date}</td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-1 rounded text-xs font-medium ${
                                result.status === "Completed"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-yellow-100 text-yellow-800"
                              }`}
                            >
                              {result.status}
                            </span>
                          </td>
                          <td className="py-3 px-4">{result.result}</td>
                          <td className="py-3 px-4">
                            <Button variant="outline" size="sm" onClick={() => setSelectedResult(result)}>
                              View
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      {selectedResult && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Lab Result Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Patient</label>
                <p className="text-lg font-semibold">{selectedResult.patient}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Test Type</label>
                <p className="text-lg font-semibold">{selectedResult.test}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Date</label>
                <p className="text-lg font-semibold">{selectedResult.date}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Status</label>
                <p className="text-lg font-semibold">{selectedResult.status}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Result</label>
                <p className="text-lg font-semibold">{selectedResult.result}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Details</label>
                <p className="text-base">{selectedResult.details}</p>
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={() => setSelectedResult(null)} className="flex-1">
                  Close
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  Download PDF
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
