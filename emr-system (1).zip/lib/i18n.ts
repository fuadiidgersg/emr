// Multilingual translations for EMR system
export const translations = {
  en: {
    // Navigation
    dashboard: "Dashboard",
    patients: "Patients",
    appointments: "Appointments",
    labResults: "Lab Results",
    prescriptions: "Prescriptions",
    wardPatients: "Ward Patients",
    vitals: "Vitals",
    medication: "Medication",
    reports: "Reports",
    inventory: "Inventory",
    orders: "Orders",
    users: "Users",
    departments: "Departments",
    activityLogs: "Activity Logs",
    settings: "Settings",
    profile: "Profile",
    logout: "Logout",

    // Common
    home: "Home",
    search: "Search",
    filter: "Filter",
    add: "Add",
    edit: "Edit",
    delete: "Delete",
    save: "Save",
    cancel: "Cancel",
    submit: "Submit",
    loading: "Loading...",
    error: "Error",
    success: "Success",

    // Doctor Dashboard
    todaysAppointments: "Today's Appointments",
    activePatients: "Active Patients",
    pendingLabs: "Pending Labs",
    addAppointment: "Add Appointment",
    appointmentTime: "Appointment Time",
    visitType: "Visit Type",
    patientName: "Patient Name",

    // Nurse Dashboard
    bedNumber: "Bed Number",
    admissionStatus: "Admission Status",
    temperature: "Temperature",
    bloodPressure: "Blood Pressure",
    pulse: "Pulse",
    notes: "Notes",
    recordVitals: "Record Vitals",

    // Pharmacy Dashboard
    medicineName: "Medicine Name",
    quantity: "Quantity",
    expiryDate: "Expiry Date",
    reorderAlerts: "Reorder Alerts",
    fulfillPrescription: "Fulfill Prescription",
    status: "Status",

    // Patient Portal
    upcomingAppointments: "Upcoming Appointments",
    recentPrescriptions: "Recent Prescriptions",
    recentLabResults: "Recent Lab Results",
    downloadReport: "Download Report",
    bloodType: "Blood Type",
    allergies: "Allergies",

    // Admin
    systemUsers: "System Users",
    departmentManagement: "Department Management",
    auditTrail: "Audit Trail",
    systemUsage: "System Usage",

    // Roles
    doctor: "Doctor",
    nurse: "Nurse",
    pharmacist: "Pharmacist",
    admin: "Admin",
    patient: "Patient",

    // Auth
    login: "Login",
    email: "Email",
    password: "Password",
    signIn: "Sign In",
    patientId: "Patient ID",
    rememberMe: "Remember Me",
    forgotPassword: "Forgot Password?",
  },
  so: {
    // Navigation
    dashboard: "Daashboorad",
    patients: "Bukaannada",
    appointments: "Kulanno",
    labResults: "Natiijada Laabka",
    prescriptions: "Daaweynta",
    wardPatients: "Bukaannada Warda",
    vitals: "Calaamadaha Nolol",
    medication: "Daaweyn",
    reports: "Warbixino",
    inventory: "Kaydka",
    orders: "Ogolyada",
    users: "Isticmaalayaasha",
    departments: "Waaxaha",
    activityLogs: "Diiwaangelinta Hawlaha",
    settings: "Tixitaannada",
    profile: "Waxyaabaha",
    logout: "Ka bax",

    // Common
    home: "Guriga",
    search: "Raadi",
    filter: "Sii",
    add: "Ku dar",
    edit: "Wax ka beddel",
    delete: "Tirtir",
    save: "Kaydi",
    cancel: "Jooji",
    submit: "Gudbiso",
    loading: "Wax la soo raadayo...",
    error: "Khalad",
    success: "Guul",

    // Doctor Dashboard
    todaysAppointments: "Kulanno Maanta",
    activePatients: "Bukaannada Firfircoon",
    pendingLabs: "Laabka Sugaya",
    addAppointment: "Ku dar Kulan",
    appointmentTime: "Waqtiga Kulanka",
    visitType: "Nooca Booqashada",
    patientName: "Magaca Bukaan",

    // Nurse Dashboard
    bedNumber: "Lambarka Sariirta",
    admissionStatus: "Xaalada Lagu Qaatay",
    temperature: "Qummanaanta",
    bloodPressure: "Cadaadiska Dhiiga",
    pulse: "Gacanaha",
    notes: "Xusuusin",
    recordVitals: "Qor Calaamadaha",

    // Pharmacy Dashboard
    medicineName: "Magaca Daaweynta",
    quantity: "Tirada",
    expiryDate: "Maalinta Dhamaadka",
    reorderAlerts: "Digniinta Dib Loo Isugu Keeno",
    fulfillPrescription: "Buuxi Daaweynta",
    status: "Xaalada",

    // Patient Portal
    upcomingAppointments: "Kulanno Soo Socda",
    recentPrescriptions: "Daaweynta Dhawaan",
    recentLabResults: "Natiijada Laabka Dhawaan",
    downloadReport: "Soo Dejiso Warbixinta",
    bloodType: "Nooca Dhiiga",
    allergies: "Waxyaabaha Lagu Xanaaqo",

    // Admin
    systemUsers: "Isticmaalayaasha Nidaamka",
    departmentManagement: "Maamulida Waaxaha",
    auditTrail: "Raadka Baadinta",
    systemUsage: "Isticmaalka Nidaamka",

    // Roles
    doctor: "Dhakhtar",
    nurse: "Caawi",
    pharmacist: "Farmacist",
    admin: "Maamuli",
    patient: "Bukaan",

    // Auth
    login: "Gal",
    email: "Iimaylka",
    password: "Erayga Sirta",
    signIn: "Gal",
    patientId: "Lambarka Bukaan",
    rememberMe: "Iska Xusuuso",
    forgotPassword: "Ilowday Erayga Sirta?",
  },
}

export type Language = "en" | "so"

export const t = (key: string, lang: Language): string => {
  return translations[lang][key as keyof (typeof translations)[Language]] || key
}
