"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface WardPatient {
  id: string
  name: string
  bedNumber: string
  admissionStatus: "admitted" | "discharged" | "critical"
  lastVitals: string
}

export function WardPatientsList() {
  const { language } = useLanguage()

  const patients: WardPatient[] = [
    {
      id: "1",
      name: "Ahmed Hassan",
      bedNumber: "A-101",
      admissionStatus: "admitted",
      lastVitals: "2 hours ago",
    },
    {
      id: "2",
      name: "Fatima Mohamed",
      bedNumber: "A-102",
      admissionStatus: "admitted",
      lastVitals: "30 minutes ago",
    },
    {
      id: "3",
      name: "Ali Ibrahim",
      bedNumber: "B-205",
      admissionStatus: "critical",
      lastVitals: "5 minutes ago",
    },
    {
      id: "4",
      name: "Zainab Ali",
      bedNumber: "A-103",
      admissionStatus: "admitted",
      lastVitals: "1 hour ago",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "admitted":
        return "bg-blue-100 text-blue-800"
      case "critical":
        return "bg-red-100 text-red-800"
      case "discharged":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("wardPatients", language)}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {patients.map((patient) => (
            <div
              key={patient.id}
              className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-secondary transition-colors"
            >
              <div className="flex-1">
                <p className="font-medium">{patient.name}</p>
                <p className="text-sm text-muted-foreground">
                  {t("bedNumber", language)}: {patient.bedNumber}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <Badge className={getStatusColor(patient.admissionStatus)}>{patient.admissionStatus}</Badge>
                  <p className="text-xs text-muted-foreground mt-1">{patient.lastVitals}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
