"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface LabResult {
  id: string
  testName: string
  date: string
  doctor: string
  status: "completed" | "pending"
}

export function LabResultsCard() {
  const { language } = useLanguage()
  const [selectedResult, setSelectedResult] = useState<LabResult | null>(null)

  const results: LabResult[] = [
    {
      id: "1",
      testName: "Complete Blood Count",
      date: "2025-10-20",
      doctor: "Dr. Amina Hassan",
      status: "completed",
    },
    {
      id: "2",
      testName: "Blood Glucose Test",
      date: "2025-10-18",
      doctor: "Dr. Hassan Ali",
      status: "completed",
    },
    {
      id: "3",
      testName: "Liver Function Test",
      date: "2025-10-22",
      doctor: "Dr. Amina Hassan",
      status: "pending",
    },
  ]

  const handleDownload = (result: LabResult) => {
    alert(`Downloading ${result.testName} from ${result.date}`)
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">{t("recentLabResults", language)}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {results.map((result) => (
            <div
              key={result.id}
              className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-secondary transition-colors"
            >
              <div className="flex-1">
                <p className="font-medium">{result.testName}</p>
                <p className="text-sm text-muted-foreground">
                  {result.date} - {result.doctor}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge
                  className={
                    result.status === "completed" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                  }
                >
                  {result.status}
                </Badge>
                {result.status === "completed" && (
                  <Button size="sm" variant="ghost" className="gap-1" onClick={() => handleDownload(result)}>
                    Download
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
