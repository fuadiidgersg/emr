"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { useAuth } from "@/lib/auth-context"
import { Icon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface SidebarProps {
  active: string
}

export function PatientSidebar({ active }: SidebarProps) {
  const { language, setLanguage } = useLanguage()
  const { logout } = useAuth()

  const menuItems = [
    { id: "dashboard", label: t("dashboard", language), icon: "LayoutDashboard" },
    { id: "appointments", label: t("appointments", language), icon: "Calendar" },
    { id: "prescriptions", label: t("prescriptions", language), icon: "Pill" },
    { id: "lab-results", label: t("labResults", language), icon: "Beaker" },
    { id: "profile", label: t("profile", language), icon: "User" },
  ]

  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border min-h-screen flex flex-col">
      <div className="p-6 border-b border-sidebar-border">
        <h1 className="text-2xl font-bold text-sidebar-primary">EMR</h1>
        <p className="text-sm text-sidebar-foreground/60">Patient Portal</p>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => {
          const isActive = active === item.id
          return (
            <Link
              key={item.id}
              href={`/patient/${item.id}`}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? "bg-sidebar-primary text-sidebar-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent"
              }`}
            >
              <Icon name={item.icon} className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border space-y-3">
        <div className="flex items-center gap-2">
          <Icon name="Globe" className="w-4 h-4" />
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as "en" | "so")}
            className="text-sm bg-sidebar border border-sidebar-border rounded px-2 py-1"
          >
            <option value="en">English</option>
            <option value="so">Somali</option>
          </select>
        </div>
        <Button onClick={logout} variant="outline" className="w-full justify-start gap-2 bg-transparent">
          <Icon name="LogOut" className="w-4 h-4" />
          {t("logout", language)}
        </Button>
      </div>
    </aside>
  )
}
