"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Icon } from "@/components/icons"

interface Appointment {
  id: string
  doctorName: string
  date: string
  time: string
  type: string
}

export function AppointmentsCard() {
  const { language } = useLanguage()

  const appointments: Appointment[] = [
    {
      id: "1",
      doctorName: "Dr. Amina Hassan",
      date: "2025-10-25",
      time: "10:00 AM",
      type: "General Checkup",
    },
    {
      id: "2",
      doctorName: "Dr. Hassan Ali",
      date: "2025-11-05",
      time: "02:00 PM",
      type: "Follow-up",
    },
  ]

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Icon name="Calendar" className="w-5 h-5" />
          {t("upcomingAppointments", language)}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {appointments.map((apt) => (
            <div key={apt.id} className="p-3 border border-border rounded-lg hover:bg-secondary transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium">{apt.doctorName}</p>
                  <p className="text-sm text-muted-foreground">
                    {apt.date} at {apt.time}
                  </p>
                  <Badge className="mt-2 bg-blue-100 text-blue-800">{apt.type}</Badge>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
