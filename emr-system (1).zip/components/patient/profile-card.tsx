"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Icon } from "@/components/icons"

export function ProfileCard() {
  const { language } = useLanguage()
  const { user } = useAuth()

  const profileData = {
    name: user?.name || "Patient Name",
    age: "35",
    gender: "Male",
    bloodType: "O+",
    allergies: "Penicillin, Shellfish",
    phone: "+252 61 234 5678",
    email: user?.email || "patient@email.com",
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("profile", language)}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16">
              <AvatarImage src={user?.avatar || "/placeholder.svg"} alt={user?.name} />
              <AvatarFallback>
                <Icon name="User" className="w-8 h-8" />
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="text-lg font-semibold">{profileData.name}</p>
              <p className="text-sm text-muted-foreground">Patient ID: P-12345</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Age</p>
              <p className="font-medium">{profileData.age}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Gender</p>
              <p className="font-medium">{profileData.gender}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("bloodType", language)}</p>
              <p className="font-medium">{profileData.bloodType}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Phone</p>
              <p className="font-medium">{profileData.phone}</p>
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-2">{t("allergies", language)}</p>
            <p className="font-medium">{profileData.allergies}</p>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-2">Email</p>
            <p className="font-medium">{profileData.email}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
