"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Icon } from "@/components/icons"

interface Prescription {
  id: string
  medicine: string
  dosage: string
  frequency: string
  prescribedBy: string
  date: string
}

export function PrescriptionsCard() {
  const { language } = useLanguage()

  const prescriptions: Prescription[] = [
    {
      id: "1",
      medicine: "Paracetamol",
      dosage: "500mg",
      frequency: "3 times daily",
      prescribedBy: "Dr. Amina Hassan",
      date: "2025-10-15",
    },
    {
      id: "2",
      medicine: "Amoxicillin",
      dosage: "250mg",
      frequency: "2 times daily",
      prescribedBy: "Dr. Hassan Ali",
      date: "2025-10-10",
    },
  ]

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Icon name="Pill" className="w-5 h-5" />
          {t("recentPrescriptions", language)}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {prescriptions.map((rx) => (
            <div key={rx.id} className="p-3 border border-border rounded-lg hover:bg-secondary transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium">{rx.medicine}</p>
                  <p className="text-sm text-muted-foreground">
                    {rx.dosage} - {rx.frequency}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">By: {rx.prescribedBy}</p>
                </div>
                <Badge className="bg-green-100 text-green-800">Active</Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
