"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Icon } from "@/components/icons"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Medicine {
  id: string
  name: string
  quantity: number
  expiryDate: string
  reorderLevel: number
}

export function InventoryTable() {
  const { language } = useLanguage()

  const medicines: Medicine[] = [
    {
      id: "1",
      name: "Paracetamol 500mg",
      quantity: 150,
      expiryDate: "2025-12-31",
      reorderLevel: 100,
    },
    {
      id: "2",
      name: "Amoxicillin 250mg",
      quantity: 45,
      expiryDate: "2025-08-15",
      reorderLevel: 50,
    },
    {
      id: "3",
      name: "Ibuprofen 400mg",
      quantity: 200,
      expiryDate: "2026-03-20",
      reorderLevel: 100,
    },
    {
      id: "4",
      name: "Metformin 500mg",
      quantity: 30,
      expiryDate: "2025-11-10",
      reorderLevel: 50,
    },
    {
      id: "5",
      name: "Lisinopril 10mg",
      quantity: 80,
      expiryDate: "2025-09-05",
      reorderLevel: 75,
    },
  ]

  const isLowStock = (quantity: number, reorderLevel: number) => quantity <= reorderLevel
  const isExpiringSoon = (expiryDate: string) => {
    const expiry = new Date(expiryDate)
    const today = new Date()
    const daysUntilExpiry = Math.floor((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    return daysUntilExpiry <= 90
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("inventory", language)}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">{t("medicineName", language)}</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">{t("quantity", language)}</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">{t("expiryDate", language)}</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">{t("status", language)}</th>
              </tr>
            </thead>
            <tbody>
              {medicines.map((medicine) => (
                <tr key={medicine.id} className="border-b border-border hover:bg-secondary">
                  <td className="py-3 px-4">{medicine.name}</td>
                  <td className="py-3 px-4">
                    <span
                      className={
                        isLowStock(medicine.quantity, medicine.reorderLevel) ? "text-destructive font-medium" : ""
                      }
                    >
                      {medicine.quantity}
                    </span>
                  </td>
                  <td className="py-3 px-4">{medicine.expiryDate}</td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      {isLowStock(medicine.quantity, medicine.reorderLevel) && (
                        <Badge className="bg-orange-100 text-orange-800 gap-1">
                          <Icon name="AlertTriangle" className="w-3 h-3" />
                          Low Stock
                        </Badge>
                      )}
                      {isExpiringSoon(medicine.expiryDate) && (
                        <Badge className="bg-red-100 text-red-800">Expiring Soon</Badge>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
