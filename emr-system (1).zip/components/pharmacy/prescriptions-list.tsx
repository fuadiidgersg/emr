"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Icon } from "@/components/icons"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface Prescription {
  id: string
  patientName: string
  doctorName: string
  medicine: string
  quantity: number
  status: "pending" | "fulfilled" | "cancelled"
}

export function PrescriptionsList() {
  const { language } = useLanguage()
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([
    {
      id: "1",
      patientName: "Ahmed Hassan",
      doctorName: "Dr. Amina",
      medicine: "Paracetamol 500mg",
      quantity: 30,
      status: "pending",
    },
    {
      id: "2",
      patientName: "Fatima Mohamed",
      doctorName: "Dr. Hassan",
      medicine: "Amoxicillin 250mg",
      quantity: 20,
      status: "pending",
    },
    {
      id: "3",
      patientName: "Ali Ibrahim",
      doctorName: "Dr. Amina",
      medicine: "Ibuprofen 400mg",
      quantity: 15,
      status: "fulfilled",
    },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "fulfilled":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleFulfillPrescription = (id: string) => {
    setPrescriptions(prescriptions.map((rx) => (rx.id === id ? { ...rx, status: "fulfilled" as const } : rx)))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("prescriptions", language)}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {prescriptions.map((prescription) => (
            <div
              key={prescription.id}
              className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-secondary transition-colors"
            >
              <div className="flex-1">
                <p className="font-medium">{prescription.patientName}</p>
                <p className="text-sm text-muted-foreground">{prescription.medicine}</p>
                <p className="text-xs text-muted-foreground">Dr: {prescription.doctorName}</p>
              </div>
              <div className="flex items-center gap-3">
                <Badge className={getStatusColor(prescription.status)}>{prescription.status}</Badge>
                {prescription.status === "pending" && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-2 bg-transparent"
                    onClick={() => handleFulfillPrescription(prescription.id)}
                  >
                    <Icon name="CheckCircle" className="w-4 h-4" />
                    {t("fulfillPrescription", language)}
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
