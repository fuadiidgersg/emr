"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface ActivityLog {
  id: string
  user: string
  action: string
  timestamp: string
  type: "create" | "update" | "delete" | "login"
}

export function ActivityLog() {
  const { language } = useLanguage()

  const logs: ActivityLog[] = [
    {
      id: "1",
      user: "Dr. Amina",
      action: "Created new patient record",
      timestamp: "2 minutes ago",
      type: "create",
    },
    {
      id: "2",
      user: "Nurse Fatima",
      action: "Updated patient vitals",
      timestamp: "15 minutes ago",
      type: "update",
    },
    {
      id: "3",
      user: "Pharmacist Ali",
      action: "Fulfilled prescription",
      timestamp: "1 hour ago",
      type: "update",
    },
    {
      id: "4",
      user: "Admin Mohamed",
      action: "Added new user",
      timestamp: "3 hours ago",
      type: "create",
    },
  ]

  const getTypeColor = (type: string) => {
    switch (type) {
      case "create":
        return "bg-green-100 text-green-800"
      case "update":
        return "bg-blue-100 text-blue-800"
      case "delete":
        return "bg-red-100 text-red-800"
      case "login":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("auditTrail", language)}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {logs.map((log) => (
            <div key={log.id} className="flex items-start justify-between p-3 border border-border rounded-lg">
              <div className="flex-1">
                <p className="font-medium">{log.user}</p>
                <p className="text-sm text-muted-foreground">{log.action}</p>
                <p className="text-xs text-muted-foreground mt-1">{log.timestamp}</p>
              </div>
              <Badge className={getTypeColor(log.type)}>{log.type}</Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
