"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface SystemUser {
  id: string
  name: string
  email: string
  role: string
  department: string
  status: "active" | "inactive"
}

export function UsersTable() {
  const { language } = useLanguage()
  const [selectedUser, setSelectedUser] = useState<SystemUser | null>(null)

  const users: SystemUser[] = [
    {
      id: "1",
      name: "Dr. Amina Hassan",
      email: "amina@hospital.com",
      role: "Doctor",
      department: "General Medicine",
      status: "active",
    },
    {
      id: "2",
      name: "Nurse Fatima",
      email: "fatima@hospital.com",
      role: "Nurse",
      department: "Ward A",
      status: "active",
    },
    {
      id: "3",
      name: "Pharmacist Ali",
      email: "ali@hospital.com",
      role: "Pharmacist",
      department: "Pharmacy",
      status: "active",
    },
    {
      id: "4",
      name: "Admin Mohamed",
      email: "admin@hospital.com",
      role: "Admin",
      department: "Administration",
      status: "active",
    },
  ]

  const getRoleColor = (role: string) => {
    switch (role) {
      case "Doctor":
        return "bg-blue-100 text-blue-800"
      case "Nurse":
        return "bg-green-100 text-green-800"
      case "Pharmacist":
        return "bg-purple-100 text-purple-800"
      case "Admin":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleUserAction = (user: SystemUser) => {
    setSelectedUser(user)
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>{t("systemUsers", language)}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Name</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Email</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Role</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Department</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Status</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">Action</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-b border-border hover:bg-secondary">
                    <td className="py-3 px-4 font-medium">{user.name}</td>
                    <td className="py-3 px-4">{user.email}</td>
                    <td className="py-3 px-4">
                      <Badge className={getRoleColor(user.role)}>{user.role}</Badge>
                    </td>
                    <td className="py-3 px-4">{user.department}</td>
                    <td className="py-3 px-4">
                      <Badge className="bg-green-100 text-green-800">{user.status}</Badge>
                    </td>
                    <td className="py-3 px-4">
                      <Button size="sm" variant="ghost" onClick={() => handleUserAction(user)}>
                        Menu
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {selectedUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>User Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Name</label>
                <p className="text-lg font-semibold">{selectedUser.name}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Email</label>
                <p className="text-base">{selectedUser.email}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-muted-foreground">Role</label>
                <p className="text-base">{selectedUser.role}</p>
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={() => setSelectedUser(null)} className="flex-1">
                  Close
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  Edit User
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  Deactivate
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  )
}
