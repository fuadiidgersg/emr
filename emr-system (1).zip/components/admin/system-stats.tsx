"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Icon } from "@/components/icons"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function SystemStats() {
  const { language } = useLanguage()

  const stats = [
    {
      title: t("systemUsers", language),
      value: "156",
      icon: "Users",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: t("doctor", language),
      value: "24",
      icon: "Stethoscope",
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: t("pharmacist", language),
      value: "12",
      icon: "Pill",
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      title: t("systemUsage", language),
      value: "94%",
      icon: "BarChart3",
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card key={index} className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            <div className={`${stat.bgColor} p-2 rounded-lg`}>
              <Icon name={stat.icon} className={`w-5 h-5 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            <p className="text-xs text-muted-foreground mt-1">Active today</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
