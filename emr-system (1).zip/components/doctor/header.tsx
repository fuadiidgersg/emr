"use client"

import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Icon } from "@/components/icons"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"

export function DoctorHeader() {
  const { user } = useAuth()
  const { language } = useLanguage()

  return (
    <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
      <div>
        <h2 className="text-2xl font-bold text-foreground">{t("dashboard", language)}</h2>
        <p className="text-sm text-muted-foreground">
          {t("doctor", language)} - {user?.name}
        </p>
      </div>

      <div className="flex items-center gap-4">
        <button className="relative p-2 hover:bg-secondary rounded-lg transition-colors">
          <Icon name="Bell" className="w-5 h-5 text-foreground" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
        </button>

        <div className="flex items-center gap-3">
          <Avatar>
            <AvatarImage src={user?.avatar || "/placeholder.svg"} alt={user?.name} />
            <AvatarFallback>
              <Icon name="User" className="w-4 h-4" />
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium text-foreground">{user?.name}</p>
            <p className="text-xs text-muted-foreground">{user?.department}</p>
          </div>
        </div>
      </div>
    </header>
  )
}
