"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Icon } from "@/components/icons"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function OverviewCards() {
  const { language } = useLanguage()

  const cards = [
    {
      title: t("todaysAppointments", language),
      value: "8",
      icon: "Calendar",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: t("activePatients", language),
      value: "24",
      icon: "Users",
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: t("pendingLabs", language),
      value: "5",
      icon: "Beaker",
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {cards.map((card, index) => (
        <Card key={index} className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
            <div className={`${card.bgColor} p-2 rounded-lg`}>
              <Icon name={card.icon} className={`w-5 h-5 ${card.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{card.value}</div>
            <p className="text-xs text-muted-foreground mt-1">Updated just now</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
