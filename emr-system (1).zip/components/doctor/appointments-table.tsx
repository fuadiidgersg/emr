"use client"

import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/i18n"
import { Icon } from "@/components/icons"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useState } from "react"

interface Appointment {
  id: string
  patientName: string
  time: string
  visitType: string
  status: "scheduled" | "completed" | "cancelled"
}

export function AppointmentsTable() {
  const { language } = useLanguage()
  const [showModal, setShowModal] = useState(false)
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: "1",
      patientName: "Ahmed Hassan",
      time: "09:00 AM",
      visitType: "General Checkup",
      status: "scheduled",
    },
    {
      id: "2",
      patientName: "Fatima Mohamed",
      time: "10:30 AM",
      visitType: "Follow-up",
      status: "scheduled",
    },
    {
      id: "3",
      patientName: "Ali Ibrahim",
      time: "02:00 PM",
      visitType: "Consultation",
      status: "scheduled",
    },
  ])

  const [formData, setFormData] = useState({
    patientName: "",
    time: "",
    visitType: "",
  })

  const handleAddAppointment = () => {
    if (formData.patientName && formData.time && formData.visitType) {
      const newAppointment: Appointment = {
        id: String(appointments.length + 1),
        patientName: formData.patientName,
        time: formData.time,
        visitType: formData.visitType,
        status: "scheduled",
      }
      setAppointments([...appointments, newAppointment])
      setFormData({ patientName: "", time: "", visitType: "" })
      setShowModal(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{t("appointments", language)}</CardTitle>
          <Button size="sm" className="gap-2" onClick={() => setShowModal(true)}>
            <Icon name="Plus" className="w-4 h-4" />
            {t("add", language)}
          </Button>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex items-center gap-2">
            <Icon name="Search" className="w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder={t("search", language)}
              className="flex-1 px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                    {t("patientName", language)}
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                    {t("appointmentTime", language)}
                  </th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">{t("visitType", language)}</th>
                  <th className="text-left py-3 px-4 font-medium text-muted-foreground">{t("status", language)}</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((apt) => (
                  <tr key={apt.id} className="border-b border-border hover:bg-secondary">
                    <td className="py-3 px-4">{apt.patientName}</td>
                    <td className="py-3 px-4">{apt.time}</td>
                    <td className="py-3 px-4">{apt.visitType}</td>
                    <td className="py-3 px-4">
                      <Badge className={getStatusColor(apt.status)}>{apt.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96 shadow-lg">
            <h2 className="text-xl font-bold mb-4">
              {t("add", language)} {t("appointments", language)}
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">{t("patientName", language)}</label>
                <input
                  type="text"
                  value={formData.patientName}
                  onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Enter patient name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">{t("appointmentTime", language)}</label>
                <input
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">{t("visitType", language)}</label>
                <select
                  value={formData.visitType}
                  onChange={(e) => setFormData({ ...formData, visitType: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">Select visit type</option>
                  <option value="General Checkup">General Checkup</option>
                  <option value="Follow-up">Follow-up</option>
                  <option value="Consultation">Consultation</option>
                  <option value="Emergency">Emergency</option>
                </select>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button variant="outline" onClick={() => setShowModal(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleAddAppointment} className="flex-1">
                Add Appointment
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
